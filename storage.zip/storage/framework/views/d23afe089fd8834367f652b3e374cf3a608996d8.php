<?php $__env->startSection('head'); ?>
<head>
	<!-- Basic Page Needs -->
	<meta charset="UTF-8">
	<!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
	<title>Blog | <?php echo e(config('app.name')); ?></title>

	<meta name="author" content="themsflat.com">

	<!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	<!-- Boostrap style -->
	<link rel="stylesheet" type="text/css" href="stylesheet/bootstrap.min.css">

	<!-- Theme style -->
	<link rel="stylesheet" type="text/css" href="stylesheet/style.css">

	<!-- Colors -->
    <link rel="stylesheet" type="text/css" href="stylesheet/colors/color1.css" id="colors">

	<!-- Reponsive -->
	<link rel="stylesheet" type="text/css" href="stylesheet/responsive.css">
	<style>
    	body{
    		background-color: black;
    		color: white;
    	}
    </style>

</head>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>
		
		<div class="page-title">
			<div class="title-heading">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<div class="page-title-heading">
								<h1 class="h1-title">BLOG</h1>
							</div><!-- /.page-title-heading -->
							<ul class="breadcrumbs">
								<li><a href="<?php echo e(route('landingpage')); ?>" title="">Home</a></li>
								<li class="dot">/</li>
								<li>Blog</li>
							</ul><!-- /.breadcrumbs -->
						</div><!-- /.col-md-12 -->
					</div><!-- /.row -->
				</div><!-- /.container -->
			</div><!-- /.title-heading -->
		</div><!-- /.page-title -->

		<section class="main-content " style="background-color: black; color: white;">
			<div class="container">
				<div class="row">
					<?php if($posts->count() > 0): ?>
					<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col-md-4 col-sm-6">
						<article class="main-post three-column">
							<div class="featured-post">
								<a href="<?php echo e(route('blog.show', $post->slug)); ?>" title="">
									<img src="<?php echo e(postImage($post->image)); ?>" alt="<?php echo e($post->title); ?>" />
								</a>
							</div><!-- /.featured-post -->
							<div class="entry-content">
								<h2>
									<a href="<?php echo e(route('blog.show', $post->slug)); ?>" title=""><?php echo e($post->title); ?></a>
								</h2>
								<?php echo e(strip_tags(str_limit($post->body, 150))); ?>

							</div><!-- /.entry-content -->
							<ul class="meta-left">
								<li class="post-date">
									<i class="fa fa-calendar"></i> <?php echo e($post->created_at->format('d M, Y')); ?>

								</li>
								
							</ul>
						</article><!-- /.main-post -->
					</div><!-- .col-md-4 col-sm-6 -->
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>

					
					
					
					
					<div class="col-md-12">
						<div class="blog-pagination center">
							<ul class="flat-pagination">
								<?php echo e($posts->appends(request()->input())->onEachSide(1)->links()); ?>

							</ul><!-- /.flat-pagination -->
						</div><!-- /.blog-pagination -->
					</div>
				</div><!-- /.row -->
			</div><!-- /.container -->
		</section><!-- /.main-content -->
<?php $__env->stopSection(); ?>		
<?php $__env->startSection('script'); ?>
	<!-- Javascript -->
    <script type="text/javascript" src="javascript/jquery.min.js"></script>
    <script type="text/javascript" src="javascript/tether.min.js"></script>
    <script type="text/javascript" src="javascript/bootstrap.min.js"></script>
    <script type="text/javascript" src="javascript/jquery.flexslider-min.js"></script>
    <script type="text/javascript" src="javascript/owl.carousel.js"></script>
    <script type="text/javascript" src="javascript/jquery.easing.js"></script>
    
    <script type="text/javascript" src="javascript/jquery.cookie.js"></script>
    <script type="text/javascript" src="javascript/waypoints.min.js"></script>
    <script type="text/javascript" src="javascript/main.js"></script>
	<!-- End Javascript -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\Laravel\cryptomining\resources\views/blog.blade.php ENDPATH**/ ?>