<div class="col-md-3">
                    <div class="profile-sidebar">
                      <!-- SIDEBAR USERPIC -->
                      
                      <!-- END SIDEBAR USERPIC -->
                      <!-- SIDEBAR USER TITLE -->
                      <div class="profile-usertitle">
                        <div class="profile-usertitle-name">
                          <?php echo e(auth()->user()->name); ?>

                        </div>
                        <div class="profile-usertitle-job">
                          <?php echo e(auth()->user()->email); ?>

                        </div>
                      </div>
                      
                      <div class="profile-usermenu">
                        <ul class="list-group">
                          <li class="list-group-item">
                            <a href="<?php echo e(route('user.index')); ?>">
                            <i class="glyphicon glyphicon-home"></i>
                            My Profile </a>
                          </li>
                          <li class="list-group-item">
                            <a href="<?php echo e(route('user.payout')); ?>">
                            <i class="glyphicon glyphicon-user"></i>
                            Payout </a>
                          </li>
                          <li class="list-group-item">
                            <a href="<?php echo e(route('user.referral')); ?>">
                            <i class="glyphicon glyphicon-share"></i>
                            Referral </a>
                          </li>
                          <li class="list-group-item">
                            <a href="<?php echo e(route('user.wallet')); ?>">
                            <i class="glyphicon glyphicon-share"></i>
                            My Wallet </a>
                          </li>
                          <li class="list-group-item">
                            <a href="<?php echo e(route('user.transaction')); ?>">
                            <i class="glyphicon glyphicon-share"></i>
                            My Transactions </a>
                          </li>
                          
                        </ul>
                      </div>
                      <!-- END MENU -->
                    </div>
                  </div><?php /**PATH C:\wamp64\Laravel\cryptomining\resources\views/inc/account.blade.php ENDPATH**/ ?>