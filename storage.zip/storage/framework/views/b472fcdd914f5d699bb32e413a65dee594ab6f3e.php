<div class="col-md-3">
                    <div class="profile-sidebar">
                      <!-- SIDEBAR USERPIC -->
                      
                      <!-- END SIDEBAR USERPIC -->
                      <!-- SIDEBAR USER TITLE -->
                      <div class="profile-usertitle">
                        <div class="profile-usertitle-name">
                          <?php echo e(auth()->user()->name); ?>

                        </div>
                        <div class="profile-usertitle-job">
                          <?php echo e(auth()->user()->email); ?>

                        </div>
                      </div>
                      
                      <div class="profile-usermenu">
                        <ul class="nav">
                          <li class="active">
                            <a href="<?php echo e(route('user.index')); ?>">
                            <i class="glyphicon glyphicon-home"></i>
                            My Profile </a>
                          </li>
                          <li>
                            <a href="<?php echo e(route('user.payout')); ?>">
                            <i class="glyphicon glyphicon-user"></i>
                            Payout </a>
                          </li>
                          
                        </ul>
                      </div>
                      <!-- END MENU -->
                    </div>
                  </div><?php /**PATH C:\wamp64\Laravel\crypto\resources\views/inc/account.blade.php ENDPATH**/ ?>