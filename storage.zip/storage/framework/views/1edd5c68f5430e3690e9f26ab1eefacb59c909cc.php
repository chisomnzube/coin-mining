<?php $__env->startSection('head'); ?>
<head>
	<!-- Basic Page Needs -->
	<meta charset="UTF-8">
	<!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
	<title><?php echo e($post->title); ?> | <?php echo e(config('app.name')); ?></title>

	<meta name="author" content="themsflat.com">

	<!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	<!-- Boostrap style -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('stylesheet/bootstrap.min.css')); ?>">

	<!-- Theme style -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('stylesheet/style.css')); ?>">

	<!-- Colors -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('stylesheet/colors/color1.css')); ?>" id="colors">

	<!-- Reponsive -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('stylesheet/responsive.css')); ?>">


</head>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
		
		

		<section class="main-content">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<article class="main-post main-single">
							<div class="featured-post">
								<a href="#" title="">
									<img src="<?php echo e(postImage($post->image)); ?>" alt="<?php echo e($post->title); ?>" />
								</a>
							</div><!-- /.featured-post -->
							<div class="entry-title">
								<h2>
									<?php echo e($post->title); ?>

								</h2>
								<ul class="meta-left">
									<li class="post-date">
										<i class="fa fa-calendar"></i> <?php echo e($post->created_at->format('d M, Y')); ?>

									</li>
									
								</ul>
							</div>
							<div class="entry-content">
								<?php echo $post->body; ?>

							</div><!-- /.entry-content -->
							
							<div class="clearfix"></div>
						</article>
						
					</div><!-- /.col-md-12 -->
				</div><!-- /.row -->
			</div><!-- /.container -->
		</section><!-- /.main-content -->
<?php $__env->stopSection(); ?>		
<?php $__env->startSection('script'); ?>

	<!-- Javascript -->
    <script type="text/javascript" src="<?php echo e(asset('javascript/jquery.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('javascript/tether.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('javascript/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('javascript/jquery.flexslider-min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('javascript/owl.carousel.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('javascript/jquery.easing.js')); ?>"></script>
    
    <script type="text/javascript" src="<?php echo e(asset('javascript/jquery.cookie.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('javascript/waypoints.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('javascript/main.js')); ?>"></script>
	<!-- End Javascript -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\Laravel\crypto\resources\views/blog-single.blade.php ENDPATH**/ ?>