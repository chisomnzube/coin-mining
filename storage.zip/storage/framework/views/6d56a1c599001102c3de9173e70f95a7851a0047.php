<?php $__env->startSection('head'); ?>
<head>
	<!-- Basic Page Needs -->
	<meta charset="UTF-8">
	<!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
	<title>Payment | <?php echo e(config('app.name')); ?></title>

	<meta name="author" content="themsflat.com">

	<!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	<!-- Boostrap style -->
	<link rel="stylesheet" type="text/css" href="stylesheet/bootstrap.min.css">

	<!-- Theme style -->
	<link rel="stylesheet" type="text/css" href="stylesheet/style.css">

	<!-- Colors -->
    <link rel="stylesheet" type="text/css" href="stylesheet/colors/color1.css" id="colors">

	<!-- Reponsive -->
	<link rel="stylesheet" type="text/css" href="stylesheet/responsive.css">

</head>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>		
		

		<section class="error-404 not-found" style="background-image: url('images/bg.jpeg');">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="wrap-error center">
							
							<div id="particles-js"></div>
							<div id="app" class="container">
								<div class="row">
									<div class="col-md-6" style="margin: auto; background: white; padding: 20px; box-shadow: 10px 10px 5px #888;">
										<div class="panel-heading">
											<h2><b>Investment Package: <?php echo e(strtoupper($package)); ?></b></h2>
										</div>
										<hr>
										<form action="<?php echo e(route('payment.process')); ?>" method="POST" class="form-group">
											<?php echo csrf_field(); ?>
											<label for="amount">Amount (USD)</label>
											<input min="<?php echo e($min); ?>" max="<?php echo e($max); ?>" type="number" name="amount" class="form-control">
											<br>
											<label for="email">Email Address</label>
											<input type="email" name="email" class="form-control" value="<?php echo e(auth()->user()->email); ?>">
											<br>
											<input type="hidden" name="package" value="<?php echo e($package); ?>">
											<button type="submit" class="btn btn-success btn-block">Invest</button>
										</form>

									</div>

									
								</div>
							</div>
							
						</div><!-- /.wrap-error -->
					</div><!-- /.col-md-12 -->
				</div><!-- /.row -->
			</div><!-- /.container -->
		</section><!-- /.error-404 -->	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
	<script >
		particlesJS.load("particles-js", "json/particles.json", function() {
			console.log("particles loaded");
		});
	</script>
	<!-- Javascript -->
	<script type="text/javascript" src="js/particles.min.js"></script>

    <script type="text/javascript" src="javascript/jquery.min.js"></script>
    <script type="text/javascript" src="javascript/tether.min.js"></script>
    <script type="text/javascript" src="javascript/bootstrap.min.js"></script>
    <script type="text/javascript" src="javascript/jquery.flexslider-min.js"></script>
    <script type="text/javascript" src="javascript/owl.carousel.js"></script>
    <script type="text/javascript" src="javascript/jquery.easing.js"></script>
    
    <script type="text/javascript" src="javascript/jquery.cookie.js"></script>
    <script type="text/javascript" src="javascript/waypoints.min.js"></script>
    <script type="text/javascript" src="javascript/main.js"></script>
	<!-- End Javascript -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\Laravel\cryptomining\resources\views/payment.blade.php ENDPATH**/ ?>