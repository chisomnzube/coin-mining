<?php $__env->startSection('head'); ?>
<head>
	<!-- Basic Page Needs -->
	<meta charset="UTF-8">
	<!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
	<title>Payment | <?php echo e(config('app.name')); ?></title>

	<meta name="author" content="themsflat.com">

	<!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	<!-- Boostrap style -->
	<link rel="stylesheet" type="text/css" href="stylesheet/bootstrap.min.css">

	<!-- Theme style -->
	<link rel="stylesheet" type="text/css" href="stylesheet/style.css">

	<!-- Colors -->
    <link rel="stylesheet" type="text/css" href="stylesheet/colors/color1.css" id="colors">

	<!-- Reponsive -->
	<link rel="stylesheet" type="text/css" href="stylesheet/responsive.css">

	<!-- Favicon and touch icons  -->
    <link href="icon/apple-touch-icon-48-precomposed.png" rel="apple-touch-icon-precomposed">
    <link href="icon/apple-touch-icon-32-precomposed.png" rel="apple-touch-icon-precomposed">
    <link href="icon/favicon.png" rel="shortcut icon">

</head>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>		
		

		<section class="error-404 not-found" style="background-image: url('images/bg.jpeg');">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="wrap-error center">
							
							<div id="particles-js"></div>
							<div id="app" class="container">
								<div class="row">
									<div class="col-md-6" style="margin: auto; background: white; padding: 20px; box-shadow: 10px 10px 5px #888;">
										<div class="panel-heading">
											<h1>Pay with cryptocurrency</h1>
											<p><b>to <?php echo e($username); ?></b></p>
										</div>
										<hr>
										<form action="<?php echo e(route('payment.process')); ?>" method="POST" class="form-group">
											<?php echo csrf_field(); ?>
											<label for="amount">Amount (<?php echo e($rcurrency); ?>)</label>
											<h1><?php echo e($result['result']['amount']); ?> <?php echo e($rcurrency); ?></h1>
											<hr>
											<a href="<?php echo e($result['result']['status_url']); ?>" class="btn btn-success btn-block">Pay Now</a>
										</form>

									</div>

									
								</div>
							</div>
							
						</div><!-- /.wrap-error -->
					</div><!-- /.col-md-12 -->
				</div><!-- /.row -->
			</div><!-- /.container -->
		</section><!-- /.error-404 -->	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
	<script >
		particlesJS.load("particles-js", "json/particles.json", function() {
			console.log("particles loaded");
		});
	</script>
	<!-- Javascript -->
	<script type="text/javascript" src="js/particles.min.js"></script>

    <script type="text/javascript" src="javascript/jquery.min.js"></script>
    <script type="text/javascript" src="javascript/tether.min.js"></script>
    <script type="text/javascript" src="javascript/bootstrap.min.js"></script>
    <script type="text/javascript" src="javascript/jquery.flexslider-min.js"></script>
    <script type="text/javascript" src="javascript/owl.carousel.js"></script>
    <script type="text/javascript" src="javascript/jquery.easing.js"></script>
    
    <script type="text/javascript" src="javascript/jquery.cookie.js"></script>
    <script type="text/javascript" src="javascript/waypoints.min.js"></script>
    <script type="text/javascript" src="javascript/main.js"></script>
	<!-- End Javascript -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\Laravel\crypto\resources\views/payment-create.blade.php ENDPATH**/ ?>